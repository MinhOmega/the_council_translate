The Council Episode 1 DB Text Tool
Coded by Delutto - Tribo Gamer Brasil 2018
www.tribogamer.com

1 - Usage

 1.1 - Parameters
       [option] <File.db> <File.txt>
       Options: -e = Export Texts
		        -i = Import Texts
		        -h = This Help
		 
       Or just run the tool from executable, a dialog option will be showed.

 1.2 - Export: -e
       The_Council_Episode_1_DB_Text_Tool.exe -e common_loc_en_0.db common_loc_en_0.txt
 
 1.3 - Import: -i (Point to original file)
       The_Council_Episode_1_DB_Text_Tool.exe -i common_loc_en_0.db common_loc_en_0.txt
       Will be created a "common_loc_en_0.db.NEW" file.
 


2 - Notes

 2.1 - Both options use the same parameters order, because the tool need some unknown
       infos from original DB file to create a new one.